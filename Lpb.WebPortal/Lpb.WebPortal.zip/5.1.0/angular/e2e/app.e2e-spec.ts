import { WebPortalTemplatePage } from './app.po';

describe('WebPortal App', function() {
  let page: WebPortalTemplatePage;

  beforeEach(() => {
    page = new WebPortalTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
