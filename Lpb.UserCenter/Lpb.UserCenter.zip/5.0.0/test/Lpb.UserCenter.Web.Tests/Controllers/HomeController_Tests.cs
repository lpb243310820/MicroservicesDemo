﻿using System.Threading.Tasks;
using Lpb.UserCenter.Web.Controllers;
using Shouldly;
using Xunit;

namespace Lpb.UserCenter.Web.Tests.Controllers
{
    public class HomeController_Tests: UserCenterWebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}
