using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Lpb.UserCenter.Web.Startup;
namespace Lpb.UserCenter.Web.Tests
{
    [DependsOn(
        typeof(UserCenterWebModule),
        typeof(AbpAspNetCoreTestBaseModule)
        )]
    public class UserCenterWebTestModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(UserCenterWebTestModule).GetAssembly());
        }
    }
}