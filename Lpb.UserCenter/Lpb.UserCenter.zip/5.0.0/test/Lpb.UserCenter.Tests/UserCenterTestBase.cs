﻿using System;
using System.Threading.Tasks;
using Abp.TestBase;
using Lpb.UserCenter.EntityFrameworkCore;
using Lpb.UserCenter.Tests.TestDatas;

namespace Lpb.UserCenter.Tests
{
    public class UserCenterTestBase : AbpIntegratedTestBase<UserCenterTestModule>
    {
        public UserCenterTestBase()
        {
            UsingDbContext(context => new TestDataBuilder(context).Build());
        }

        protected virtual void UsingDbContext(Action<UserCenterDbContext> action)
        {
            using (var context = LocalIocManager.Resolve<UserCenterDbContext>())
            {
                action(context);
                context.SaveChanges();
            }
        }

        protected virtual T UsingDbContext<T>(Func<UserCenterDbContext, T> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<UserCenterDbContext>())
            {
                result = func(context);
                context.SaveChanges();
            }

            return result;
        }

        protected virtual async Task UsingDbContextAsync(Func<UserCenterDbContext, Task> action)
        {
            using (var context = LocalIocManager.Resolve<UserCenterDbContext>())
            {
                await action(context);
                await context.SaveChangesAsync(true);
            }
        }

        protected virtual async Task<T> UsingDbContextAsync<T>(Func<UserCenterDbContext, Task<T>> func)
        {
            T result;

            using (var context = LocalIocManager.Resolve<UserCenterDbContext>())
            {
                result = await func(context);
                context.SaveChanges();
            }

            return result;
        }
    }
}
