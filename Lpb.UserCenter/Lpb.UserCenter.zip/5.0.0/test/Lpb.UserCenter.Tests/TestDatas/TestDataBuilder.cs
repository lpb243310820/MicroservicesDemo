using Lpb.UserCenter.EntityFrameworkCore;

namespace Lpb.UserCenter.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly UserCenterDbContext _context;

        public TestDataBuilder(UserCenterDbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}