﻿namespace Lpb.UserCenter
{
    public class UserCenterConsts
    {
        public const string LocalizationSourceName = "UserCenter";

        public const string ConnectionStringName = "Default";
    }
}