namespace Lpb.UserCenter.Web.Controllers
{
    public class LayoutController : UserCenterControllerBase
    {

    }
}