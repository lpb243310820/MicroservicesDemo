using Lpb.Service2.EntityFrameworkCore;

namespace Lpb.Service2.Tests.TestDatas
{
    public class TestDataBuilder
    {
        private readonly Service2DbContext _context;

        public TestDataBuilder(Service2DbContext context)
        {
            _context = context;
        }

        public void Build()
        {
            //create test data here...
        }
    }
}