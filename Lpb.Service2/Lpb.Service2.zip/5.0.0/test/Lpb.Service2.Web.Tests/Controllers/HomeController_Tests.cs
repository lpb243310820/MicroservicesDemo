﻿using System.Threading.Tasks;
using Lpb.Service2.Web.Controllers;
using Shouldly;
using Xunit;

namespace Lpb.Service2.Web.Tests.Controllers
{
    public class HomeController_Tests: Service2WebTestBase
    {
        [Fact]
        public async Task Index_Test()
        {
            //Act
            var response = await GetResponseAsStringAsync(
                GetUrl<HomeController>(nameof(HomeController.Index))
            );

            //Assert
            response.ShouldNotBeNullOrEmpty();
        }
    }
}
