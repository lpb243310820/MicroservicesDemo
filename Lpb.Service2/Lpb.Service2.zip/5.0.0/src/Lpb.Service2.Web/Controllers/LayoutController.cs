namespace Lpb.Service2.Web.Controllers
{
    public class LayoutController : Service2ControllerBase
    {

    }
}