﻿namespace Lpb.Service2
{
    public class Service2Consts
    {
        public const string LocalizationSourceName = "Service2";

        public const string ConnectionStringName = "Default";
    }
}